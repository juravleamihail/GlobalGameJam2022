using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Ninja/NinjaTypeListSO")]
public class NinjaTypeListSO : ScriptableObject
{
    public List<NinjaTypeSO> ninjaList;
}

