namespace States
{
    public enum EStates{
        MainMenu = 0,
        Gameplay = 1,
        Combat = 2,
        Move = 3
    }
}